﻿using Assignment4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<string> RestList = new List<string>();

            foreach (Restaurant r in Restaurant.GetRestaurants())
            {
                if (ModelState.IsValid)
                    //the ensures that these won't make the program crash if left null
                    //default values if fav dish and website are null
                {
                    string? FavDish = r.FavDish ?? "They're all tasty!";
                    string? Phone = r.Phone;
                    string? Website = r.Website ?? "Coming soon!";

                    //prints out the values in a string format, refer to Restaurantlist.cshtml for the printed list
                    RestList.Add($"Rank # { r.Rank}: { r.Name} <br/> Address:  {r.Address} <br/> Phone: { Phone} <br/>  Website: {Website} <br/> Favorite Dish: { FavDish}");

                }
                else
                {
                    return View();
                }

            }
            return View(RestList);
        }
        //getter and setter for the form found on Submissions.cs (i also made the fields required)
        [HttpGet]
        public IActionResult SubmitForm()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SubmitForm(Submissions applicationResponse)
        {
            if (ModelState.IsValid)
            {
                TempStorage.AddApplication(applicationResponse);
                return View("Confirmation", applicationResponse);
            }
            else
            {
                return View();
            }
        }
        public IActionResult RestaurantList()
        {
            return View(TempStorage.Applications);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
