﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    //seperate model for the form users can submit
    //ensure it is in the Phone format
    public class Submissions
    { 
        [Required]
        public string Name { get; set; }
        [Required]
        public string YourName { get; set; }
        [RegularExpression(@"^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$", ErrorMessage = "Please put in the (000) 000-0000 format")]
        public string Phone { get; set; }
        [Required]
        public string FavDish { get; set; }
    }
}
