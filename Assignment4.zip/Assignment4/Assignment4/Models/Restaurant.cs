﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    //restaurant class for my top 5 restaurants
    public class Restaurant
    {
        //makes it so the rank is read only
        public Restaurant(int rank)
        {
            Rank = rank;
        }
        //all the fields for the indec page (top 5 food places)
        //? allows the values to be replaced with something else when null (in controller)
        [Required]
        public int Rank { get; }
        [Required]
        public string Name { get; set; }
        public string? FavDish { get; set; }
        [Required]
        public string Address { get; set; }
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Please put in the (000)000-0000 format")]
        public string Phone { get; set; }
        public string? Website { get; set; }

        //restaurants info for the array
        public static Restaurant[] GetRestaurants()
        {
            Restaurant R1 = new Restaurant(1)
            {
                Name = "Silver Dish Thai Cuisine",
                FavDish = "Massaman Curry",
                Address = "278 W Center St, Provo, UT 84601",
                Phone = "8013739540",
                Website = "https://silverdishthaicuisine.com/"
            };
            Restaurant R2 = new Restaurant(2)
            {
                Name = "Cubby's",
                FavDish = "Massaman Curry",
                Address = "1258 N State St, Provo, UT 84604",
                Phone = "8013739540",
                Website = "https://cubbys.co/"
            };
            Restaurant R3 = new Restaurant(3)
            {
                Name = "Sweeto Burritot",
                FavDish = null,
                Address = "292 N. University Ave, Provo, UT 84601",
                Phone = "8013739540",
                Website = "https://sweetoburrito.com/"
            };
            Restaurant R4 = new Restaurant(4)
            {
                Name = "Asa Ramen",
                FavDish = "Pork Broth",
                Address = "278 W Center St, Provo, UT 84601",
                Phone = "8013739540",
                Website = null
            };
            Restaurant R5 = new Restaurant(5)
            {
                Name = "In-N-Out",
                FavDish = "Double-Double",
                Address = "293 University Parkway, Orem, UT,  84660",
                Phone = "8013739540",
                Website = null
            };

            return new Restaurant[] { R1, R2, R3, R4, R5 };
        }
    }
}
